### Chapter 5

# Acquisition and Appraisal Elements

* 5.1   [Custodial History (Added Value)](01_custodial_history.html)
* 5.2   [Immediate Source of Acquisition (Added Value)](02_immediate_source_of_acquisition.html)
* 5.3   [Appraisal, Destruction, and Scheduling Information (Added Value)](03_appraisal_destruction_and_scheduling_information.html)
* 5.4   [Accruals (Added Value)](04_accruals.html)

