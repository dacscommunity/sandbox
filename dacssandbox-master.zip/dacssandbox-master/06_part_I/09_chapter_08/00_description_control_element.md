### Chapter 8

# Description Control Element

* 8.1   [Description Control Element](01_description_control.html)
* 8.2   [Rights Statements for Archival Description](02_rights_statements_archival_description.html)