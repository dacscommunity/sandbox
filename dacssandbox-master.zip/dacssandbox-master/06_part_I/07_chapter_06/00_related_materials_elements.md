### Chapter 6

# Related Materials Elements

* 6.1   [Existence and Location of Originals (Added Value)](01_existence_and_location_of_originals.html)
* 6.2   [Existence and Location of Copies (Added Value)](02_existence_and_location_of_copies.html)
* 6.3   [Related Archival Materials (Added Value)](03_related_archival_materials.html)
* 6.4   [Publication Note (Added Value)](04_publication_note.html)

