### Chapter 4

# Conditions of Access and Use Elements

* 4.1   [Conditions Governing Access (Required)](01_conditions_governing_access.html)
* 4.2   [Physical Access (Added Value)](02_physical_access.html)
* 4.3   [Technical Access (Added Value)](03_technical_access.html)
* 4.4   [Conditions Governing Reproduction and Use (Added Value)](04_conditions_governing_reproduction_and_use.html)
* 4.5   [Languages and Scripts of the Material (Required)](05_languages_and_scripts_of_the_material.html)
* 4.6   [Finding Aids (Added Value)](06_finding_aids.html)

