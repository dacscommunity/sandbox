### Chapter 7

# Notes Element

* 7.1   [Notes (Added Value)](01_notes.html)