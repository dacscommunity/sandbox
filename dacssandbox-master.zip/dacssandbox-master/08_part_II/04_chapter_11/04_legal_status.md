# 11.4 Legal Status

**11.4.1** For corporate bodies, record the legal status and, where appropriate, the type of corporate body together with the covering dates when this status applied. Where possible, terms should be applied from a controlled vocabulary. Dates should be recorded as described in rules 11.1.4-11.1.5.

<p class="dacs-example">Public limited company (<em>for Rolls-Royce Ltd.; term from Companies House registry</em>)</p>
