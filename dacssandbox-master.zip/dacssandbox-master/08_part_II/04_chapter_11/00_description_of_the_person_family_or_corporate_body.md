### Chapter 11

# Description of the Person, Family, or Corporate Body

* 11.1   [Dates of Existence (Required)](01_dates_of_existence.html)
* 11.2   [Historical Summary](02_historical_summary.html)
* 11.3   [Places](03_places.html)
* 11.4   [Legal Status](04_legal_status.html)
* 11.5   [Functions, Occupations, and Activities](05_functions_occupations_and_activities.html)
* 11.6   [Mandates/Source of Authority](06_mandates_source_of_authority.html)
* 11.7   [Internal Structure/Genealogy](07_internal_structure_genealogy.html)
* 11.8   [Example Description of the Person, Family, or Corporate Body Area of an Archival Authority Record](08_example.html)

