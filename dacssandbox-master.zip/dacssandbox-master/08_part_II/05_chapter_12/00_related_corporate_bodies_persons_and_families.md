### Chapter 12

# Related Corporate Bodies, Persons, and Families

* 12.1   [Names/Identifiers of Related Corporate Bodies, Persons, or Families](01_names_identifiers_of_related_corporate_bodies_persons_or_families.html)
* 12.2   [Type of Related Entity](02_type_of_related_entity.html)
* 12.3   [Nature of Relationship](03_nature_of_relationship.html)
* 12.4   [Dates of the Relationship](04_dates_of_the_relationship.html)
* 12.5   [Example Related Persons, Families, and Corporate Bodies Area of an Archival Authority Record](05_example.html)

