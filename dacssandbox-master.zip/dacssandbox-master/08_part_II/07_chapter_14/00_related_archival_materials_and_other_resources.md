### Chapter 14

# Related Archival Materials and Other Resources

* 14.1   [Identifiers and Titles of Related Resources](01_identifiers_and_titles_of_related_resources.html)
* 14.2   [Types of Related Resources](02_types_of_related_resources.html)
* 14.3   [Nature of Relationship to Related Resources](03_nature_of_relationship_to_related_resources.html)
* 14.4   [Dates of Related Resources and/or Relationships](04_dates_of_related_resources_and_or_relationships.html)
* 14.5   [Example Related Archival Materials and Other Resources Area of an Archival Authority Record](05_example.html)

