## 14.4 Dates of Related Resources and/or Relationships

**14.4.1** Provide any relevant dates for the related resources or the relationship between the corporate body, person, or family and the related resource, and describe the significance of those dates.

<p class="dacs-example">Photographs of Arts and Culture in Ghana (<em>related resource</em>)</p>

<p class="dacs-example">circa 1970 (<em>date of related resource</em>)</p>

<p class="dacs-example">Remarks to Peace Corps Trainees (<em>related resource</em>)</p>

<p class="dacs-example">8 September 1962 (<em>date of related resource</em>)</p>


