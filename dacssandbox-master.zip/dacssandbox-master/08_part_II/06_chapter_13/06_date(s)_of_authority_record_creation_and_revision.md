# 13.6 Date(s) of Authority Record Creation and Revision

**13.6.1** Record the action taken and the date(s) on which the authority record was prepared or revised.

<p class="dacs-example">Created 12 August 1998. Revised 18 December 2002.</p>
