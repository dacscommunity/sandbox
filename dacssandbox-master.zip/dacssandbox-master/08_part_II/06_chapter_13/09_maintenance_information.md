# 13.9 Maintenance Information

**13.9.1** Record the name(s) of the person(s) who prepared or revised the authority record and any other information pertinent to its creation or maintenance.

<p class="dacs-example">Biographical data assembled by Lael Ramaley.</p>

<p class="dacs-example">Occupations revised by Lina Bountouri.</p>

<p class="dacs-example">Created by M. K. K. Yearl</p>


