# 13.8 Sources

**13.8.1** Record relevant information about sources consulted in establishing or revising the authority record. Establish a consistent policy regarding the content, form, and placement of citation of sources.

<p class="dacs-example">Caro, Robert A. <em>The Years of Lyndon Johnson</em>. New York: Knopf, 1982-2002.</p>

<p class="dacs-example">Utah history encyclopedia, via WWW, Oct. 4, 2011.</p>

<p class="dacs-example">Rice C. Ballard Papers #4850, Southern Historical Collection, Wilson Library, University of North Carolina at Chapel Hill.</p>

<p class="dacs-example">Trustees of Tufts College. Bulletin of Tufts University Undergraduate Colleges, 1970-1971, Vol. LXX, no. 4. Medford, MA: Tufts University, 1970.</p>
