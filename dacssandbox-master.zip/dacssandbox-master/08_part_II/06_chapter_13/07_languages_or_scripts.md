# 13.7 Languages or Scripts

**13.7.1** Record the language or script of the archival authority record.

<p class="dacs-example">English</p>
