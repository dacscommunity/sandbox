### Chapter 13

# Authority Record Management

* 13.1   [Repository Code](01_repository_code.html)
* 13.2   [Authority Record Identifier (Required)](02_authority_record_identifier.html)
* 13.3   [Rules or Conventions](03_rules_or_conventions.html)
* 13.4   [Status](04_status.html)
* 13.5   [Level of Detail](05_level_of_detail.html)
* 13.6   [Date(s) of Authority Record Creation and Revision](06_dates_of_authority_record_creation_and_revision.html)
* 13.7   [Languages or Scripts](07_languages_or_scripts.html)
* 13.8   [Sources](08_sources.html)
* 13.9   [Maintenance Information](09_maintenance_information.html)
* 13.10  [Example Authority Record Management Area of an Archival Authority Record](10_example.html)
* 13.11  [Rights Statement for Archival Authority Records (Required)](11_rights_statement_for_archival_authority_records.html)

