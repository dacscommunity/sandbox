# 10.4 Identifiers for Corporate Bodies

**10.4.1** Record where possible an official or other identifier for the corporate body and the jurisdiction that assigned it.

<p class="dacs-example">Registered company 01003142 (Companies House, England)</p>

<p class="dacs-example"><em>For the corporate body</em> Rolls Royce PLC</p>

