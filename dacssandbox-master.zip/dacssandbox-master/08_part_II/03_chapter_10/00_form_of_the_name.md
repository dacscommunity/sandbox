### Chapter 10

# Form of the Name

* 10.1   [Authorized Form of the Name (Required)](01_authorized_form_of_the_name.html)
* 10.2   [Type of Entity (Required)](02_type_of_entity.html)
* 10.3   [Variant Forms of Names](03_variant_forms_of_names.html)
* 10.4   [Identifiers for Corporate Bodies](04_identifiers_for_corporate_bodies.html)
* 10.5   [Form of the Name Area of an Archival Authority Record](05_example.html)

